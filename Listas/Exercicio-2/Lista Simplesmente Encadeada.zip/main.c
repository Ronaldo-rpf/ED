#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "Interface.h"

int main(){
    lstEncadeada();
    return 0;
}
